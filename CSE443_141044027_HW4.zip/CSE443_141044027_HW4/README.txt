Program calisitirilmasi icin once ServerApp sinifi calisitirilmasi gerekiyor .
Daha sonra ClientApp sinifi calistirilmasi gerekiyor . 
Program farklı bilgisayarlarda denendi , calisiyor .
package sample;

import sample.Q2.implementation.proxy.RmiProtectionInterface;
import sample.Q2.implementation.proxy.RmiRemoteInterface;
import sample.Q2.implementation.proxy.RmiVirtualInterface;
import sample.Q2.implementation.Customer;
import sample.Q2.implementation.templateGraph.ListGraph;
import sample.Q2.implementation.strategy.StrategyContext;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

/**
 * Client ın isteklerine cevap verecek olan sınıftır .
 * Grekli interface leri implement ederek Client ile iletişim sağlacaktır .
 * RMI kullanır .
 * İçerisinde vectorle Customer tipinde kullanıcıları tutar .
 */
public class ServerApp extends UnicastRemoteObject implements RmiVirtualInterface,RmiProtectionInterface,RmiRemoteInterface {

	/**
	 * Data fields
	 */
	public Vector<Customer> users;
	StrategyContext strategyContext;

	/**
	 * Constructor
	 * @throws RemoteException
	 */
	public ServerApp() throws RemoteException {
		super();
		users = new Vector<>(10);
	}

	/**
	 * RMI bağlantısını başlatır
	 */
	public void startServer(){
		try {
			System.setProperty("java.rmi.server.hostname","localhost");
			Registry registry= LocateRegistry.createRegistry(8888);
			registry.bind("//localhost/ServerApp", new ServerApp());
			System.err.println("ServerApp ready");
		} catch (Exception e) {
			System.err.println("ServerApp exception: " + e.toString());
			e.printStackTrace();
		}
	}

	/**
	 * Main
	 * @param args
	 * @throws RemoteException
	 */
	public static void main(String args[]) throws RemoteException {
		ServerApp serverApp = new ServerApp();
		serverApp.startServer();
	}

	/**
	 * Logın için kontrol yapar
	 * @param userName
	 * @param passwd
	 * @return String
	 * @throws RemoteException
	 */
	@Override
	public String logInCommand(String userName, String passwd) throws RemoteException {
		for (Customer a :users) {
			if(a.getUsername().equals(userName))
				if(a.getPasswd().equals(passwd))
					return "ok";
		}
		return "error";
	}

	/**
	 * Username e göre Customer return eder .
	 * @param username
	 * @return Customer
	 * @throws RemoteException
	 */
	@Override
	public Customer getCustomerFromServer(String username) throws RemoteException {
		for (Customer a: users) {
			if(a.getUsername().equals(username))
				return a;
		}
		return null;
	}

	/**
	 * Customer kayıt eder
	 * @param customer
	 * @return String
	 * @throws RemoteException
	 */
	@Override
	public String saveCustomerToServer(Customer customer) throws RemoteException {
		for (Customer a :users) {
			if(a.getUsername().equals(customer.getUsername()))
				return "usernameerror";
		}
		customer.setCost(100);
		users.add(customer);
		System.out.println("Username: "+customer.getUsername()+" eklendi");
		return "ok";
	}

	/**
	 * Client için hesaplama yapar
	 * @param input
	 * @param customer
	 * @param algo
	 * @return STRİNG
	 * @throws InterruptedException
	 */
	@Override
	public Customer sendDataToCalculate(ListGraph input, Customer customer, String algo) throws InterruptedException {
		//System.out.println(input.toString());
		getCurrentTimeUsingDate();
		this.strategyContext = new StrategyContext(algo);
		if(algo.equals("MST") && customer.getCost()>=40){
			customer.setCost(customer.getCost() - 40);
		}else if(algo.equals("Incidence_Matrix") && customer.getCost()>=20){
			customer.setCost(customer.getCost() - 20);
		}else
			customer.setMessage("costError");
		if(!customer.getMessage().equals("costError")){
			long startTime = System.nanoTime();
			//Thread.sleep(2000);
			customer.setMessage(this.strategyContext.calculate(input));
			long stopTime = System.nanoTime();
			System.out.println("ExecutionTime :"+(stopTime-startTime)+" nanoseconds");
		}
		return customer;
	}

	/**
	 * Client için cost alma metodu
	 * @param customer
	 * @return Customer
	 * @throws RemoteException
	 */
	@Override
	public Customer buyCostFromServer(Customer customer) throws RemoteException {
		customer.setCost(customer.getCost()+100);
		return customer;
	}

	/**
	 * Ekrana zamanı print eder.
	 */
	public static void getCurrentTimeUsingDate() {
		Date date = new Date();
		String strDateFormat = "hh:mm:ss a";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		String formattedDate= dateFormat.format(date);
		System.out.println("Current time of request :" + formattedDate);
	}
}
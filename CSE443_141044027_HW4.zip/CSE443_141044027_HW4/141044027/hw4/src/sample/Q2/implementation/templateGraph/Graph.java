package sample.Q2.implementation.templateGraph;

import java.io.Serializable;
import java.util.Iterator;

/**
 * Graph interface
 */
public interface Graph extends Serializable {

    /**
     * getter number vertex
     * @return int
     */
    int getNumV();

    /**
     * Number of edges
     * @return int
     */
    int getNumE();

    /**
     * control graph is directed or undirected
     * @return true or false
     */
    boolean isDirected();

    /**
     * insert to graph myEdge
     * @param myEdge
     */
     void insert(MyEdge myEdge);

    /**
     * is there edge like that
     * @param source
     * @param dest
     * @return true or false
     */
    boolean isEdge(int source, int dest);

    /**
     * getter edge
     * @param source
     * @param dest
     * @return MyEdge
     */
     MyEdge getEdge(int source, int dest);

    /**
     * iterator edge
     * @param source
     * @return Iterator
     */
    Iterator<MyEdge> edgeIterator(int source);
}


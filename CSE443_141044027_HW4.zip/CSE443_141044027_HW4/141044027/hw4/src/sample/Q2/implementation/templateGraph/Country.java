package sample.Q2.implementation.templateGraph;

/**
 * Örnek Türetilmiş Edge sınıfı
 */
public class Country extends MyEdge {
    private String base;
    private String target;

    /**
     * My Special Distance
     */
    public class Distance implements MyCalculatable{

        double val;

        /**
         * Constructor
         * @param a
         */
        public Distance(double a){
            this.val=a;
        }

        @Override
        public double getWeight() {
            return this.val;
        }

        @Override
        public int compareTo(Object o) {
            return 0;
        }
    }

    /**
     * Constructor
     * @param base
     * @param target
     * @param source
     * @param destination
     * @param dist
     */
    public Country(String base, String target, int source, int destination, long dist) {
        super(source, destination);
        this.setWeight(new Distance(dist));
        this.base = base;
        this.target = target;
    }

    /**
     * toString
     * @return
     */
    public String toString() {
        return this.base + " ==> " + this.target + " : "+this.getCalculatedWeight();
    }

    public static void main(String args[]){
        ListGraph cities = new ListGraph(5, true);
        cities.insert(new Country("A", "B", 0, 1, 12L));
        cities.insert(new Country("B", "C", 1, 2, 19L));
        cities.insert(new Country("A", "C", 0, 2, 11L));
        cities.insert(new Country("A", "D", 0, 3, 16L));
        cities.insert(new Country("C", "D", 2, 3, 13L));
        cities.insert(new Country("D", "B", 3, 1, 23L));
        cities.insert(new Country("A", "E", 0, 4, 17L));
        cities.insert(new Country("D", "E", 3, 4, 15L));
        cities.insert(new Country("E", "A", 4, 0, 15L));
    }
}

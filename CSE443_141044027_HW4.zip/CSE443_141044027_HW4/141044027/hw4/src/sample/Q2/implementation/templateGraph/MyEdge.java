package sample.Q2.implementation.templateGraph;

import java.io.Serializable;

/**
 * MyEdge sınıfı
 */
public abstract class MyEdge<T extends MyCalculatable> implements Serializable {
    /**
     * Data fields
     */
    private int source;
    private int dest;
    private T weight;

    /**
     * Constructor
     * @param source
     * @param dest
     */
    public MyEdge(int source, int dest) {
        this.source = source;
        this.dest = dest;
        this.weight = null;
    }

    /**
     * Constructor
     * @param source
     * @param dest
     * @param w
     */
    public MyEdge(int source, int dest, T w) {
        this.source = source;
        this.dest = dest;
        weight = w;
    }

    /**
     * getter source
     * @return int
     */
    public int getSource() {
        return source;
    }

    /**
     * getter destination
     * @return int
     */
    public int getDest() {
        return dest;
    }

    /**
     * return weight
     * @return double
     */
    public T getWeight() {
        return weight;
    }

    public Double getCalculatedWeight(){
        return this.weight.getWeight();
    }

    /**
     * toString
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[(");
        sb.append(Integer.toString(source));
        sb.append(", ");
        sb.append(Integer.toString(dest));
        sb.append("): ");
        sb.append(Double.toString(getCalculatedWeight()));
        sb.append("]");
        return sb.toString();
    }

    /**
     *
     * @param obj
     * @return true or false
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MyEdge) {
            MyEdge myEdge = (MyEdge) obj;
            return (source == myEdge.source && dest == myEdge.dest);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (source << 16) ^ dest;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public void setDest(int dest) {
        this.dest = dest;
    }

    public void setWeight(T weight) {
        this.weight = weight;
    }
}


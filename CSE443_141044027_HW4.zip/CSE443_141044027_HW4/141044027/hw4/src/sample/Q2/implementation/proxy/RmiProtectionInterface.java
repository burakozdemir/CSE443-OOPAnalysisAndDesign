package sample.Q2.implementation.proxy;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Protection proxy interface
 */
public interface RmiProtectionInterface extends Remote {
    /**
     * login control
     * @param userName
     * @param passwd
     * @return String
     * @throws RemoteException
     */
    String logInCommand(String userName,String passwd) throws RemoteException;
}

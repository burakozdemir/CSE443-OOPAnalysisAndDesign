package sample.Q2.implementation.proxy;

import sample.Q2.implementation.Customer;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Remote Proxy İnterface
 */
public interface RmiRemoteInterface extends Remote {
    /**
     * Kullanıcı adına göre username
     * @param username
     * @return Customer
     * @throws RemoteException
     */
    Customer getCustomerFromServer(String username) throws RemoteException;

    /**
     * Customer kayıt eder .
     * @param customer
     * @return String
     * @throws RemoteException
     */
    String saveCustomerToServer(Customer customer) throws RemoteException;
}

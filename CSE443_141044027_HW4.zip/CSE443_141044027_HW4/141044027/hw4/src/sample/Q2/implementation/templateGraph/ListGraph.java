package sample.Q2.implementation.templateGraph;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * List yapısı ile oluşturulmuş graph
 */
public class ListGraph extends AbstractGraph implements Serializable {
    /**
     * Data fields
     */
    private static final long serialVersionUID = 1L;
    private LinkedList<MyEdge>[] edges;
    private ArrayList<MyEdge> edgesAll;

    /**
     * Constructor
     * @param numV
     * @param directed
     */
    public ListGraph(int numV, boolean directed) {
        super(numV, directed);
        edgesAll=new ArrayList<>();
        this.edges = new LinkedList[numV];
        for(int i = 0; i < numV; ++i)
            this.edges[i] = new LinkedList();
    }

    /**
     * To String
     * @return String
     */
    @Override
    public String toString(){
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < edges.length; i++) {
            for (MyEdge a: edges[i]) {
                stringBuilder.append(a.getSource()+" - "+a.getDest()+" - "+a.getCalculatedWeight());
            }
            stringBuilder.append('\n');
        }
        return stringBuilder.toString();
    }

    /**
     * Getter edges
     * @return ArrayList
     */
    public ArrayList<MyEdge> getedges(){
        return this.edgesAll;
    }

    /**
     * Getter num edges
     * @return
     */
    @Override
    public int getNumE() {
        int result = 0;
        for(int i = 0; i < this.getNumV(); ++i) {
            Iterator it = this.edgeIterator(i);
            while(it.hasNext()) {
                ++result;
                it.next();
            }
        }
        return result;
    }

    /**
     * getter num vertexes
     * @return LinkedList
     */
    public LinkedList getAllVertexes(){
        LinkedList result = new LinkedList();
        for (int i = 0; i < edges.length; i++) {
            for (MyEdge a: edges[i]) {
               if(!result.contains(a.getDest()))
                   result.add(a.getDest());
               if(!result.contains(a.getSource()))
                   result.add(a.getSource());
            }
        }
        return result;
    }

    /**
     * insert edge to graph
     * @param myEdge
     */
    @Override
    public void insert(MyEdge myEdge) {
        this.edges[myEdge.getSource()].add(myEdge);
        this.edgesAll.add(myEdge);
        if (!this.isDirected())
            this.edges[myEdge.getDest()].add(myEdge);
    }

    /**
     * edge control
     * @param source
     * @param dest
     * @return boolean
     */
    @Override
    public boolean isEdge(int source, int dest) {
        Iterator it = this.edgeIterator(source);
        do {
            if (!it.hasNext())
                return false;
        } while(((MyEdge)it.next()).getDest() != dest);
        return true;
    }

    /**
     * edge getter
     * @param source
     * @param dest
     * @return MyEdge
     */
    @Override
    public MyEdge getEdge(int source, int dest) {
        Iterator it = this.edges[source].iterator();
        MyEdge myEdge;
        do {
            if (!it.hasNext())
                return null;
            myEdge = (MyEdge)it.next();
        } while(myEdge.getDest() != dest);
        return myEdge;
    }

    /**
     * Iterator
     * @param source
     * @return Iterator
     */
    @Override
    public Iterator<MyEdge> edgeIterator(int source) {
        return this.edges[source].iterator();
    }
}

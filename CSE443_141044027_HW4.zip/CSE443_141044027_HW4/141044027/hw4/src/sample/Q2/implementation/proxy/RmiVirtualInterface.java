package sample.Q2.implementation.proxy;

import sample.Q2.implementation.Customer;
import sample.Q2.implementation.templateGraph.ListGraph;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Virtual Proxy Interface
 */
public interface RmiVirtualInterface extends Remote {
    /**
     * hesaplama fonksiyonu
     * @param input
     * @param customer
     * @param algo
     * @return Customer
     * @throws RemoteException
     * @throws InterruptedException
     */
    Customer sendDataToCalculate(ListGraph input, Customer customer, String algo) throws RemoteException, InterruptedException;

    /**
     * Buy cost
     * @param customer
     * @return Customer
     * @throws RemoteException
     */
    Customer buyCostFromServer(Customer customer) throws RemoteException;
}

package sample.Q2.implementation.templateGraph;

import java.io.Serializable;

/**
 * Karsılastırılmak icin ortak interface
 */
public interface MyCalculatable extends Comparable, Serializable {
    double getWeight();
}
package sample.Q2.implementation.proxy;

import sample.Q2.implementation.Customer;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Remote Proxy Impl
 */
public class RemoteProxy implements RmiRemoteInterface {

    /**
     * Data field
     */
    private RmiRemoteInterface rmiRemoteInterface;

    /**
     * Constructor
     * @throws RemoteException
     * @throws NotBoundException
     */
    public RemoteProxy() throws RemoteException, NotBoundException {
        Registry registry = LocateRegistry.getRegistry("localhost",8888);
        rmiRemoteInterface = (RmiRemoteInterface) registry.lookup("//localhost/ServerApp");
    }

    /**
     * Kullanıcı adına göre serverdan Customer çeker
     * @param username
     * @return Customer
     * @throws RemoteException
     */
    @Override
    public Customer getCustomerFromServer(String username) throws RemoteException {
        return this.rmiRemoteInterface.getCustomerFromServer(username);
    }

    /**
     * Customer kayıt eder .
     * @param customer
     * @return String
     * @throws RemoteException
     */
    @Override
    public String saveCustomerToServer(Customer customer) throws RemoteException {
        return this.rmiRemoteInterface.saveCustomerToServer(customer);
    }

}

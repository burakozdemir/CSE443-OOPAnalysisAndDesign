package sample.Q2.implementation.strategy;

import sample.Q2.implementation.templateGraph.ListGraph;

/**
 * Minimum Spanning Tree
 */
public class MST extends AlgoritmAbstract {

    /**
     * Constructor
     */
    public MST() {
        super();
    }

    /**
     * Overrided Metod
     * @param input
     * @return
     */
    @Override
    public String calculate(ListGraph input){

        return "";
    }
}

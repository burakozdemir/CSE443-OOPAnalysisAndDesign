package sample.Q2.implementation.templateGraph;

/**
 * Graph ortak abstract sınıf
 */
public abstract class AbstractGraph implements Graph {
    /**
     * Data field
     */
    private int numV;
    private boolean directed;

    /**
     * Constuructor
     * @param numV
     * @param directed
     */
    public AbstractGraph(int numV, boolean directed) {
        this.numV = numV;
        this.directed = directed;
    }

    /**
     * Getters
     */

    public int getNumV() {
        return this.numV;
    }

    public boolean isDirected() {
        return this.directed;
    }
}

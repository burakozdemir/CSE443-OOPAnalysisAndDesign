package sample.Q2.implementation.proxy;

import sample.Q2.implementation.Customer;
import sample.Q2.implementation.templateGraph.ListGraph;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Virtual Proxy Impl
 */
public class VirtualProxy implements RmiVirtualInterface {

    /**
     * Data field
     */
    private RmiVirtualInterface rmiVirtualInterface;
    /**
     * Constructor
     */
    public VirtualProxy() throws RemoteException, NotBoundException {
        Registry registry = LocateRegistry.getRegistry("localhost",8888);
        this.rmiVirtualInterface = (RmiVirtualInterface) registry.lookup("//localhost/ServerApp");
    }

    /**
     * Overrided metod
     * @param input
     * @param customer
     * @param algo
     * @return Customer
     * @throws RemoteException
     * @throws InterruptedException
     */
    @Override
    public Customer sendDataToCalculate(ListGraph input, Customer customer, String algo) throws RemoteException, InterruptedException {
        return this.rmiVirtualInterface.sendDataToCalculate(input,customer,algo);
    }

    /**
     * Overrrided metod
     * @param customer
     * @return Customer
     * @throws RemoteException
     */
    @Override
    public Customer buyCostFromServer(Customer customer) throws RemoteException {
        return this.rmiVirtualInterface.buyCostFromServer(customer);
    }
}

package sample.Q2.implementation;

import java.io.Serializable;

/**
 * User account sınıfı
 */
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Data fields
     */
    private String name,surname,username,passwd,cardInf,message;
    private Integer cost;


    /**
     * Constructor
     */
    public Customer(){
        this.name = "";
        this.surname = "";
        this.username="";
        this.passwd="";
        this.cardInf = "";
        this.message = "";
        this.cost= 0;
    }

    /**
     * Constructor
     * @param name
     * @param surname
     * @param username
     * @param passwd
     * @param cardInf
     */
    public Customer(String name, String surname,String username,String passwd,String cardInf) {
        this.name = name;
        this.surname = surname;
        this.username=username;
        this.passwd=passwd;
        this.cardInf = cardInf;
        this.cost= 0;
        this.message= "";
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getCardInf() {
        return cardInf;
    }

    public void setCardInf(String cardInf) {
        this.cardInf = cardInf;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getCost() {
        return cost;
    }

    public void setCost(Integer cost) {
        this.cost = cost;
    }


}

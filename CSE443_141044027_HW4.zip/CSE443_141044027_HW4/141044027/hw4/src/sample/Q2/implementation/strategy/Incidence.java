package sample.Q2.implementation.strategy;

import sample.Q2.implementation.templateGraph.ListGraph;
import sample.Q2.implementation.templateGraph.MyEdge;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Incidence_Matrix
 */
public class Incidence extends AlgoritmAbstract {


    /**
     * Constructor
     */
    public Incidence() {
        super();
    }

    /**
     * Overrided metod
     * @param input
     * @return String
     */
    @Override
    public String calculate(ListGraph input){
        StringBuilder result = new StringBuilder();
        int [][] resultValue = new int[input.getNumV()][input.getNumE()];
        int index=0;
        List<Integer> vs = new ArrayList<Integer>(input.getAllVertexes());
        for(Iterator<MyEdge> it = input.getedges().iterator();it.hasNext();index++){
            MyEdge de = it.next();
            Integer from = de.getSource();
            Integer to = de.getDest();
            int j = vs.indexOf(from);
            int k = vs.indexOf(to);
            resultValue[j][index]=0;
            resultValue[k][index]=1;
        }
        for (int i = 0; i < input.getNumV(); i++) {
            for (int j = 0; j < input.getNumE(); j++) {
                result.append(resultValue[i][j]);
                result.append(" ");
            }
            result.append('\n');
        }
        return result.toString();
    }
}

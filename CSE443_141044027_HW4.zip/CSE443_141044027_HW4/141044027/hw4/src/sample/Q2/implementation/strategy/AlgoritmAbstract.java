package sample.Q2.implementation.strategy;


import sample.Q2.implementation.templateGraph.Country;
import sample.Q2.implementation.templateGraph.ListGraph;

/**
 * Abstract Algorithm Sınıfıdır .
 * Graph yapılarını hesaplamak için ara sınıftır . Ortak metodlar buradadır.
 */
public abstract class AlgoritmAbstract {

    /**
     * Helper
     * @param input
     * @return ListGraph
     */
    public static ListGraph stringToGraph (String input){
        String[] lines = input.split("\\r?\\n");
        int vertexNumber = Integer.parseInt(lines[0]);
        ListGraph result = new ListGraph(vertexNumber,true);
        for (int i = 1; i < lines.length ; i++) {
            String[] line = lines[i].split(",");
            result.insert(new Country(line[0],line[1],Integer.parseInt(line[0])
                    , Integer.parseInt(line[1]),Integer.parseInt(line[2])));
        }
        return result;
    }

    /**
     * Abstract motod
     * @param input
     * @return String
     */
    public abstract String calculate(ListGraph input);
}

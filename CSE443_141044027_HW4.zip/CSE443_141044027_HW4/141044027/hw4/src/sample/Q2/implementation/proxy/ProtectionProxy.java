package sample.Q2.implementation.proxy;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Protection Proxy Impl
 */
public class ProtectionProxy implements RmiProtectionInterface {

    /**
     * Data field
     */
    private RmiProtectionInterface rmiProtectionInterface;

    /**
     * Constructor
     * @throws RemoteException
     * @throws NotBoundException
     */
    public ProtectionProxy() throws RemoteException, NotBoundException {
        Registry registry = LocateRegistry.getRegistry("localhost",8888);
        this.rmiProtectionInterface = (RmiProtectionInterface) registry.lookup("//localhost/ServerApp");
    }

    /**
     * Logın control
     * @param userName
     * @param passwd
     * @return String
     * @throws RemoteException
     */
    @Override
    public String logInCommand(String userName, String passwd) throws RemoteException {
        return this.rmiProtectionInterface.logInCommand(userName,passwd);
    }
}

package sample.Q2.implementation.strategy;

import sample.Q2.implementation.templateGraph.ListGraph;

/**
 *  İçinde Algoritmalar için abstract ortak sınıf barındırır
 */
public class StrategyContext {
    /**
     * Data field
     */
    private AlgoritmAbstract algoritmAbstract;

    /**
     * Constructor . Parametreye göre datafielda atama yapar
     * @param algorithm
     */
    public StrategyContext(String algorithm){
        if(algorithm.equals("MST"))
            this.algoritmAbstract=new MST();
        else if(algorithm.equals("Incidence_Matrix"))
            this.algoritmAbstract=new Incidence();
        else
            System.out.println("No Method For Algorithm");
    }

    /**
     * Datafield ın metodunu cagırarak hesaplama yapar
     * @param input
     * @return String
     */
    public String calculate(ListGraph input){
        if(this.algoritmAbstract!=null)
            return this.algoritmAbstract.calculate(input);
        else
            return "algorithmError";
    }
}

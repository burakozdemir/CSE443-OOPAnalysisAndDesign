package sample.Q1;

/**
 * NeedingSleep sınıfı .State sınıfını extend eder
 */
public class NeedingSleep extends State {

    /**
     * Constructor
     */
    public NeedingSleep() {
        System.out.println("NeedingSleep_State");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        if(context.getBehaviour().equals("sleep")){
            System.out.println("NeedingSleep -> Ready : "+context.getBehaviour());
            context.setState(new Ready());
        }else if(context.getBehaviour().equals("coffe&work")){
            System.out.println("NeedingSleep -> ChronicIlness : "+context.getBehaviour());
            context.setState(new ChronicIlness());
        }
        else{
            System.out.println("No Behaviour");
        }
    }
}

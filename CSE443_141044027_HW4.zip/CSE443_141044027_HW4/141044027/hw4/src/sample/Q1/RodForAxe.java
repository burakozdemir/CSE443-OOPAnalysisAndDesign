package sample.Q1;

/**
 * RodForAxe sınıfı . State sınıfını extend eder
 */
public class RodForAxe extends State {

    /**
     * Consturctor
     */
    public RodForAxe() {
        System.out.println("RodForAxe");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        System.out.println("Final State : RodForAxe");
    }
}

package sample.Q1;

/**
 * Fit Sınıfı .State sınıfını extend eder
 */
public class Fit extends State {

    /**
     * Constructor
     */
    public Fit() {
        System.out.println("Fit_State");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        if(context.getBehaviour().equals("hardwork&perseverance")){
            System.out.println("Fit -> Graduate : "+context.getBehaviour());
            context.setState(new Graduate());
        }else{
            System.out.println("No Behaviour");
        }
    }
}

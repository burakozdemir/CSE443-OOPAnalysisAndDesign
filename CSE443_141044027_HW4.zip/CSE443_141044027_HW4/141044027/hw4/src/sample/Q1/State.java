package sample.Q1;

/**
 * State durumları için ortak abstract sınıf
 */
public abstract class State {
    String name ;
    public State(){

    }

    /**
     * State sınıfları için implement edilecek metod
     * @param context
     */
    public abstract void handleState(Context context);
}

package sample.Q1;

/**
 * Ready sınıfı . State sınıfını extend eder
 */
public class Ready extends State {

    /**
     * Constructor
     */
    public Ready(){
        System.out.println("Ready_State");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        if(context.getBehaviour().equals("hardwork&perseverance")){
            System.out.println("Ready -> graduate : "+context.getBehaviour());
            context.setState(new Graduate());
        }
        else if(context.getBehaviour().equals("exercise")){
            System.out.println("Ready -> fit : "+context.getBehaviour());
            context.setState(new Fit());
        }
        else if(context.getBehaviour().equals("cheating")){
            System.out.println("Ready -> RodForAxe : "+context.getBehaviour());
            context.setState(new RodForAxe());
        }
        else if(context.getBehaviour().equals("buying_GTX1080")){
            System.out.println("Ready -> RodForAxe : "+context.getBehaviour());
            context.setState(new RodForAxe());
        }
        else if(context.getBehaviour().equals("out_till_late")){
            System.out.println("Ready -> NeedingSleep : "+context.getBehaviour());
            context.setState(new NeedingSleep());
        }
        else{
            System.out.println("No Behaviour");
        }
    }
}

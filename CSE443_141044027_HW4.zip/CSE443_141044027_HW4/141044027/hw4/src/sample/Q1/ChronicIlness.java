package sample.Q1;

/**
 * ChronicIlness Sınıfı . State sınıfını extend eder
 */
public class ChronicIlness extends State {

    /**
     * Constructor
     */
    public ChronicIlness() {
        System.out.println("ChronicIlness_State");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        System.out.println("Final State : ChronicIlness");
    }
}

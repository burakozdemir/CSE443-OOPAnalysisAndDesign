package sample.Q1;

/**
 * Test
 */
public class TestQ1 {
    /**
     * Main
     * @param args
     */
    public static void main(String args[]){
        System.out.print("Context : ");
        Context context = new Context();
        System.out.print("Context1 : ");
        Context context1 = new Context();
        System.out.print("Context2 : ");
        Context context2 = new Context();

        System.out.println("--------------------- Path_1 ---------------------");
        context.setBehaviour("exercise");
        context.getState().handleState(context);
        context.setBehaviour("hardwork&perseverance");
        context.getState().handleState(context);

        System.out.println("--------------------- Path_2 ---------------------");
        context1.setBehaviour("out_till_late");
        context1.getState().handleState(context1);
        context1.setBehaviour("coffe&work");
        context1.getState().handleState(context1);

        System.out.println("--------------------- Path_3 ---------------------");
        context2.setBehaviour("out_till_late");
        context2.getState().handleState(context2);
        context2.setBehaviour("sleep");
        context2.getState().handleState(context2);
        context2.setBehaviour("cheating");
        context2.getState().handleState(context2);


    }
}

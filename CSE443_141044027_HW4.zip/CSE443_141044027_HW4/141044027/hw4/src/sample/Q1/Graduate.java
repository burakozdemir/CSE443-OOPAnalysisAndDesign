package sample.Q1;

/**
 * Graduate sınıfı . State sınıfını extend eder
 */
public class Graduate extends State {

    /**
     * Constructor
     */
    public Graduate() {
        System.out.println("Graduate_State");
    }

    /**
     * Overrided metod
     * @param context
     */
    @Override
    public void handleState(Context context) {
        System.out.println("Final State : Graduate");
    }
}

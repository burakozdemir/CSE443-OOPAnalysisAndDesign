package sample.Q1;

/**
 * State Tasarım kalıbı için Context sınıfı
 */
public class Context {
    /**
     * Data Fields
     */
    private String behaviour;
    private State state;

    /**
     * Constuctor
     */
    public Context(){
        this.state = new Ready();
    }

    /**
     * Setters and getters
     */

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public String getBehaviour() {
        return behaviour;
    }

    public void setBehaviour(String behaviour) {
        this.behaviour = behaviour;
    }
}

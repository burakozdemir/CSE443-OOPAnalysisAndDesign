package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import sample.Q2.implementation.strategy.AlgoritmAbstract;
import sample.Q2.implementation.Customer;
import sample.Q2.implementation.templateGraph.ListGraph;
import sample.Q2.implementation.proxy.VirtualProxy;

import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ResourceBundle;

/**
 * User ekranı için contoller
 */
public class LogInController implements Initializable{

    /**
     * Data fields Customer ve RMI
     */
    Customer customer;
    VirtualProxy virtualProxy;

    /**
     * DataFıelds for GUI
     */
    @FXML
    TextArea inputTextArea;

    @FXML
    TextArea outputTextArea;

    @FXML
    Button resultButton;

    @FXML
    TextField processTextField;
    @FXML
    ComboBox<String> comboBox;
    @FXML
    TextField userCost;
    @FXML
    TextField username;
    @FXML
    Label processTextFielda;
    @FXML
    Label processTextFields;


    /**
     * Constructor
     * @throws RemoteException
     * @throws NotBoundException
     */
    public LogInController() throws RemoteException, NotBoundException {
        //this.server=new ServerApp();
        this.customer=new Customer("","","","","");
        this.virtualProxy = new VirtualProxy();
    }

    /**
     * Calculate button
     * @param e
     * @throws RemoteException
     * @throws InterruptedException
     */
    @FXML
    void calculate(ActionEvent e) throws RemoteException, InterruptedException {
        if(customer.getCost()>=40){
            String input=inputTextArea.getText();

            processTextField.clear();
            processTextField.setText("Waiting ServerApp Response");

            ListGraph graph = AlgoritmAbstract.stringToGraph(input);
            this.customer=this.virtualProxy.sendDataToCalculate(graph,customer,comboBox.getValue());

            userCost.clear();
            userCost.setText(this.customer.getCost().toString());

            outputTextArea.clear();
            outputTextArea.setText(this.customer.getMessage());

            processTextField.clear();
            processTextField.setText("Done");

        }else{
            processTextField.clear();
            processTextField.setText("No enough cost");
        }
    }

    /**
     * BuyCost button
     * @param e
     * @throws RemoteException
     */
    @FXML
    void buyCost(ActionEvent e) throws RemoteException {
        //String result = server.buyCost(this.customer);
        this.customer = this.virtualProxy.buyCostFromServer(this.customer);

        userCost.clear();
        userCost.setText(this.customer.getCost().toString());
        processTextField.clear();
        processTextField.setText("Bought the new cost");
    }

    /**
     * intialize metodu for GUI
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> list = FXCollections.observableArrayList();
        list.addAll("MST","Incidence_Matrix");
        comboBox.setItems(list);
    }

    /**
     * Maın controllerdan user controller a veri aktarmak için yazılmıştır
     * @param customer
     * @param virtualProxy
     */
    void initData(Customer customer, VirtualProxy virtualProxy){
        //this.server=server;
        this.virtualProxy=virtualProxy;
        this.customer=customer;
        username.setText(this.customer.getUsername());
        userCost.setText(this.customer.getCost().toString());
    }

}

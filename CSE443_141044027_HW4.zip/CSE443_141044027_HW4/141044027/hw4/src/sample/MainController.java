package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sample.Q2.implementation.Customer;
import sample.Q2.implementation.proxy.ProtectionProxy;
import sample.Q2.implementation.proxy.RemoteProxy;
import sample.Q2.implementation.proxy.VirtualProxy;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ResourceBundle;

/**
 * Client ın kullandığı ana ekran için maincontroller
 */
public class MainController implements Initializable {

    /**
     * Data fields for GUI
     */
    @FXML
    public TextField name;
    @FXML
    public TextField surname;
    @FXML
    public TextField username;
    @FXML
    public TextField password;
    @FXML
    public TextField cardinf;
    @FXML
    public Button savebutton;
    @FXML
    public TextField processsignin;

    @FXML
    public Button login;
    @FXML
    public TextField loginusername;
    @FXML
    public TextField loginuserpassword;
    @FXML
    public TextField processlogin;

    /**
     * Data fields for RMI
     */
    ProtectionProxy protectionProxy ;
    RemoteProxy remoteProxy;
    VirtualProxy virtualProxy;
    //ServerApp server ;

    /**
     * Constructor
     * @throws RemoteException
     * @throws MalformedURLException
     * @throws NotBoundException
     */
    public MainController() throws RemoteException, MalformedURLException, NotBoundException {
        this.protectionProxy = new ProtectionProxy();
        this.remoteProxy = new RemoteProxy();
        this.virtualProxy = new VirtualProxy();

    }

    /**
     * Kayıt butonu
     * @param e
     * @throws IOException
     */
    @FXML
    private void signIn(ActionEvent e) throws IOException {
        Customer newCust = new Customer(name.getText(),surname.getText(),username.getText(),password.getText(),
                cardinf.getText());
        //String result = server.saveCustomer(newCust);
        String result = remoteProxy.saveCustomerToServer(newCust);
        if(result.equals("ok")){
            processsignin.clear();
            processsignin.setText("Eklendi");
        }else {
            processsignin.clear();
            processsignin.setText("Eklenemedi");
        }
    }

    /**
     * Giriş butonu
     * @param e
     * @throws IOException
     */
    @FXML
    private void login(ActionEvent e) throws IOException {
        //String result=server.logInCheck(loginusername.getText(),loginuserpassword.getText());
        String result = protectionProxy.logInCommand(loginusername.getText(),loginuserpassword.getText());
        if(result.equals("ok")){
            processlogin.clear();
            processlogin.setText("LoggedIn");
            createUserWindow(remoteProxy.getCustomerFromServer(loginusername.getText()));
        }else{
            processlogin.clear();
            processlogin.setText("Loggin Error");
        }
    }

    /**
     * helper
     * @param customer
     * @throws IOException
     */
    private void createUserWindow(Customer customer) throws IOException {
        Stage stage = showUserDialog(customer);
        stage.showAndWait();
    }

    /**
     * User için yeni ekran açar
     * @param customer
     * @return Stage
     * @throws IOException
     */
    public Stage showUserDialog(Customer customer) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource(
                        "sample.fxml"
                )
        );

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setScene(new Scene(loader.load()));

        LogInController controller =
                loader.<LogInController>getController();
        controller.initData(customer,this.virtualProxy);

        return stage;
    }

    /**
     * Stage için initiliaza metodu
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        processsignin.setText("Connected the ServerApp");
    }
}

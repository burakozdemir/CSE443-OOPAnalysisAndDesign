package sample.Q4;

/**
 * Discrete Foruier Transform CLass. Extend DiscreteTransform
 */
public class myDFT extends DiscreteTransform{

    /**
     * Değerine göre execution time ı ekrana basmak için kullanılır .
     */
    boolean timeFlag;

    /**
     * Constructor
     * @param readPath
     * @param writePath
     * @param timeFlag
     */
    public myDFT(String readPath,String writePath,boolean timeFlag){
        super(readPath,writePath);
        this.timeFlag=timeFlag;
    }

    /**
     * Overrided doTransform method . Process of DFT
     */
    @Override
    public void doTransform() {
        long t0 = System.nanoTime();
        for (int N = 0; N < countNumbers; N++) {
            double sumreal = 0;
            double sumimag = 0;
            for (int k = 0; k < countNumbers; k++) {
                double formula = 2 * Math.PI * k * N / countNumbers;
                sumreal +=  numbers[k].real * Math.cos(formula) +
                        numbers[k].imaginary * Math.sin(formula);
                sumimag += -numbers[k].real * Math.sin(formula) +
                        numbers[k].imaginary * Math.cos(formula);
            }
            calculatedNumbers[N].real = sumreal;
            calculatedNumbers[N].imaginary = sumimag;
        }
        long t1 = System.nanoTime();
        long elapsedTime = t1 - t0 ;
        if(timeFlag==true)
            System.out.print("Execution time(nano) :" + elapsedTime);
    }
}

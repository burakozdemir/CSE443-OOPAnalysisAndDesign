package sample.Q4;

/**
 * ComplexNumber için yazılmış sınıf
 */
public class ComplexNum {
    /**
     * Datafields
     */
    public double real ;
    public double imaginary ;

    /**
     * Constructor
     * @param real
     * @param imaginary
     */
    public ComplexNum(double real,double imaginary){
        this.real=real;
        this.imaginary=imaginary;
    }

    /**
     * Default COnstructor
     */
    public ComplexNum(){
        this.real=0;
        this.imaginary=0;
    }
}

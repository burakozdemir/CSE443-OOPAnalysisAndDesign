package sample.Q4;

/**
 * Discrete Cosine Transform 2 CLass. Extend DiscreteTransform
 */
public class myDCT2 extends DiscreteTransform{

    /**
     * Constructor
     * @param readPath
     * @param writePath
     */
    public myDCT2(String readPath,String writePath){
        super(readPath,writePath);
    }

    /**
     * Overrided doTransform method . Process of DCT2
     */
    @Override
    public void doTransform() {
        for (int N = 0; N < countNumbers; N++) {
            double realToplam = 0;
            double imaginaryToplam = 0;
            for (int k = 0; k < countNumbers; k++) {
                double formula = (Math.PI/countNumbers)*(k + 0.5)*N;
                realToplam +=  numbers[k].real * Math.cos(formula) +
                        numbers[k].imaginary * Math.sin(formula);
                imaginaryToplam += -numbers[k].real * Math.sin(formula) +
                        numbers[k].imaginary * Math.cos(formula);
            }
            calculatedNumbers[N].real = realToplam;
            calculatedNumbers[N].imaginary = imaginaryToplam;
        }
    }
}

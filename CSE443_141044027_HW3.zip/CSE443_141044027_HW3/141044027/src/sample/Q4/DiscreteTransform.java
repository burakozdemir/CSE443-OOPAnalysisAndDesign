package sample.Q4;

import java.io.*;

/**
 * Template Design Pattern için abstract sınıf
 */
public abstract class DiscreteTransform {
    /**
     * Dosyadan okunan complex sayılar
     */
    public ComplexNum[] numbers;

    /**
     * Dosyaya yazılan complex sayılar
     */
    public ComplexNum[] calculatedNumbers;

    /**
     * Sayıların miktarı
     */
    public int countNumbers=0;
    /**
     * OKunacak ve yazılacak pathler
     */
    String readPath , writePath;

    /**
     * Constructor
     * @param readPath
     * @param writePath
     */
    public DiscreteTransform(String readPath,String writePath){
        this.readPath=readPath;
        this.writePath=writePath;
    }

    /**
     * Template method
     * @throws IOException
     */
    final void template() throws IOException {
        readNumbersFromFile(readPath);
        doTransform();
        writeNumbersToFile(writePath);
    }

    /**
     * abstract method . türeyen sınıflara özel implement edilecek
     */
    public abstract void doTransform();

    /**
     * Read numbers from specific file
     * @param path
     * @throws IOException
     */
    final public void readNumbersFromFile(String path) throws IOException {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            countNumbers = Integer.parseInt(line);

            /**
             * Get memory from heap
             */
            this.numbers=new ComplexNum[countNumbers];
            this.calculatedNumbers=new ComplexNum[countNumbers];

            line = reader.readLine();
            int count = 0;
            while (line != null) {
                String[] splited = line.split(",");
                /**
                 * Data ile hem yer alma hemde assign işlemi
                 */
                this.numbers[count]= new ComplexNum(Double.parseDouble(splited[0]),Double.parseDouble(splited[1]));
                this.calculatedNumbers[count]= new ComplexNum(0,0);

                line = reader.readLine();
                count++;
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Write numbers to specific file
     * @param path
     */
    final public void writeNumbersToFile(String path){
        File file = new File(path);
        FileWriter fr = null;
        StringBuilder res = new StringBuilder();
        try {
            fr = new FileWriter(file);
            res.append(String.valueOf(countNumbers)+"\n");
            for (int i = 0; i < countNumbers; i++) {
                res.append(String.format("%.2f",calculatedNumbers[i].real));
                res.append(';');
                res.append(String.format("%.2f",calculatedNumbers[i].imaginary));
                res.append('\n');
            }
            fr.write(res.toString());

        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

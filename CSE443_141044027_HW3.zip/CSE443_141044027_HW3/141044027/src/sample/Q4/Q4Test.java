package sample.Q4;

import java.io.File;
import java.io.IOException;

/**
 * Q4Test Class
 */
public class Q4Test {
    /**
     * Pathprefix
     */
    static String pathPrefix = System.getProperty("user.dir")
            + File.separator+"src"+File.separator+"sample"+File.separator+"Q4"+File.separator;

    /**
     * static main method
     * @param args
     * @throws IOException
     */
    public static void main(String args[]) throws IOException {
        try {
            /**
             * Dft
             */
            DiscreteTransform transformDFT = new myDFT(pathPrefix+"readNumbers",
                    pathPrefix+"dftRes.txt",true);

            /**
             * DFT process
             */
            transformDFT.template();

            /**
             * Dct
             */
            DiscreteTransform transformDCT = new myDCT2(pathPrefix+"readNumbers",pathPrefix+"dctRes.txt");

            /**
             * Dct Process
             */
            transformDCT.template();

        }catch (Exception e){
            System.err.println(e.getMessage());
        }
    }
}

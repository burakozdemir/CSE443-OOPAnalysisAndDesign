package sample.Q2;

/**
 * Mailler için ortak abstract sınıf
 */
public abstract class MailAdress {
    /**
     * Data Field
     */
    String name;
    String surname;
    String mail ;

    /**
     * Constructor
     * @param name
     * @param surname
     * @param mail
     */
    public MailAdress(String name,String surname,String mail){
        this.name=name;
        this.surname=surname;
        this.mail=mail;
    }

    /**
     * Print mailaddres
     */
    public abstract void showMail();
}

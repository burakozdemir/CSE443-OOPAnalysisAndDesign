package sample.Q2;

/**
 * Q2Test
 */
public class Q2Test {

    public static void main(String args[]){
        GroupMail groupmail = new GroupMail("Burak","ozdemir","bo@gtu.edu.tr");

        groupmail.addMail(new PersonelMail("furkan","aktas","fa@gmail.com"));
        groupmail.addMail(new PersonelMail("aydin","calik","ac@hotmail.com"));
        groupmail.addMail(new PersonelMail("samet","yurt","sy@gmail.com"));
        groupmail.addMail(new PersonelMail("fero","kuruca","fk@hotmail.com"));

        GroupMail groupmail2 = new GroupMail("Cengiz","Cengiz","cc@gtu.edu.tr");
        groupmail2.addMail(groupmail);

        System.out.println("GroupMail :");
        groupmail2.showMail();
    }
}

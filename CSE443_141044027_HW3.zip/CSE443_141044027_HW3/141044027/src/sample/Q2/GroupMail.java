package sample.Q2;

import java.util.LinkedList;
import java.util.List;

/**
 * GroupMail sınıfı . İçerisinde list tutarak personel mail bilgilerini tutabilir .
 */
public class GroupMail extends MailAdress {

    /**
     * List of Personel Mails
     */
    List<MailAdress> mailAdresses;

    /**
     * Constructor
     * @param name
     * @param surname
     * @param mail
     */
    public GroupMail(String name, String surname, String mail) {
        super(name, surname, mail);
        this.mailAdresses = new LinkedList<>();
    }

    /**
     * add mailaddress
     * @param mailAdress
     */
    public void addMail(MailAdress mailAdress){
        this.mailAdresses.add(mailAdress);
    }

    /**
     * Overrided showMail
     */
    @Override
    public void showMail() {
        System.out.print("GroupMail =>");
        System.out.print(" Name:"+this.name);
        System.out.print(", SurName:"+this.surname);
        System.out.println(", Mail:"+this.mail);
        for (MailAdress item :this.mailAdresses) {
            item.showMail();
        }
    }
}

package sample.Q2;

/**
 * PersonelMail . implements MailAdress interface
 */
public class PersonelMail extends MailAdress {

    /**
     * Constructor
     * @param name
     * @param surname
     * @param mail
     */
    public PersonelMail(String name, String surname, String mail) {
        super(name, surname, mail);
    }

    /**
     * Overrided showMail
     */
    @Override
    public void showMail() {
        System.out.print("PersonelMail =>");
        System.out.print(" Name:"+this.name);
        System.out.print(", SurName:"+this.surname);
        System.out.println(", Mail:"+this.mail);
    }
}

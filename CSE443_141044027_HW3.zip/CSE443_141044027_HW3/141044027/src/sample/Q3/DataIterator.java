package sample.Q3;

/**
 * Iterator interface
 */
public interface DataIterator {
    Data next();
    boolean hasNext();
    boolean isDone();
    Data currentItem();
}

package sample.Q3;

/**
 * Aggregate interface
 */
public interface DataAggregate {
    DataIterator getIterator();
}

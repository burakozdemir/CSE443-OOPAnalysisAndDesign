package sample.Q3;

import java.util.LinkedList;
import java.util.List;

/**
 * DataAggregate interfaceini implement eden ConcreteDataAggregate sınıfı
 */
public class ConcreteDataAggregate implements DataAggregate{
    /**
     * Dataları list şeklinde içerisinde tutar
     */
    private List<Data> dataList = new LinkedList<>();

    /**
     * Data size
     * @return int
     */
    public int countData(){return this.dataList.size();}

    /**
     * add method
     * @param d
     */
    public void add(Data d){
        dataList.add(d);
    }

    /**
     * Getter for specific index value
     * @param index
     * @return Data
     */
    public Data getItem(int index){
        return dataList.get(index);
    }

    /**
     * Overrided getIterator() metodu
     * @return
     */
    @Override
    public DataIterator getIterator() {
        return new ConcreteDataIterator(this);
    }

    /**
     * Data verisi içeride varmı kontrol ediyor
     * @param data
     * @return boolean
     */
    public boolean contains(Data data){
        for (Data item : dataList) {
            if(item.equals(data))
                return true;
        }
        return false;
    }
}

package sample.Q3;

/**
 * ClockWiseTrevarse
 */
public class ClockWiseTrevarse {

    /**
     * Gezilecek olan 2d Data arrayi
     */
    private Data[][] arr;
    private int pos = 0;
    public ConcreteDataAggregate res;

    /**
     * Constructor
     * @param arr
     */
    public ClockWiseTrevarse(Data[][] arr){
        this.arr=arr;
        res = new ConcreteDataAggregate();
        int maxIter = arr.length + arr[0].length;

        clockWiseTraverse(arr,0,0,true,true,maxIter);
    }

    /**
     * Verilen 2d arrayi Clockwise şeklinde iterate eder . başlangıç row ve col positionları parametre ile verilir.
     * count maksimum ne kadar gideceğidir .
     * diğer parametrelerde hangi yönde ilerleyebileceklerini belirtir
     * @param arr2D
     * @param rowPosition
     * @param colPosition
     * @param sutunFlag
     * @param satirFlag
     * @param count
     */
    private void clockWiseTraverse(Data[][] arr2D,int rowPosition, int colPosition,
                                                   boolean sutunFlag, boolean satirFlag, int count) {

        int rowHeight = arr2D.length;
        int columnHeight = arr2D[0].length;

        /**
         * Tek column base case
         */
        if (columnHeight == 1) {
            for (int row = 0; row < rowHeight; row++) res.add(arr2D[row][0]);
            return ;
        }

        /**
         * maxİter base case
         */
        if (count < 1) return ;

        if (satirFlag) {
            if (sutunFlag) {
                for (int col = rowPosition; col < columnHeight; col++) {
                    if (res.contains(arr2D[rowPosition][col])) continue ;
                    else {
                        res.add(arr2D[rowPosition][col]);
                        colPosition = col;
                    }
                }
                rowPosition = rowPosition + 1;
                satirFlag = false;
                count = count - 1;

            } else {
                 for (int row = rowPosition; row < rowHeight; row++) {
                    if (res.contains(arr2D[row][colPosition])) continue;
                    else {
                        res.add(arr2D[row][colPosition]);
                        rowPosition = row;
                    }
                }
                colPosition = colPosition - 1;
                count = count - 1;
            }

        } else {
            if (sutunFlag) {
                for (int col = colPosition; col >= 0; col--) {
                    if (res.contains(arr2D[rowPosition][col])) continue;
                    else {
                        res.add(arr2D[rowPosition][col]);
                        colPosition = col;
                    }
                }
                rowPosition = rowPosition - 1;
                satirFlag = true;
                count = count - 1;
            } else {
                for (int row = rowPosition; row > 0; row--) {
                    if (res.contains(arr2D[row][colPosition]))continue;
                    else {
                        res.add(arr2D[row][colPosition]);
                        rowPosition = row;
                    }
                }
                colPosition = colPosition + 1;
                count = count - 1;
            }
        }
        /**
         * recall
         */
        clockWiseTraverse(arr2D, rowPosition, colPosition, !sutunFlag, !satirFlag, count);
    }

}

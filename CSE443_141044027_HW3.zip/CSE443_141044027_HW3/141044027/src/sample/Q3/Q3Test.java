package sample.Q3;

/**
 * Q3Test
 */
public class Q3Test {
    /**
     * static void main
     * @param args
     */
    public static void main(String args[]){
        Data[][] arr2d = new Data[5][5];

        int index =0 ;
        for (int i = 0; i < arr2d.length; i++) {
            for (int j = 0; j < arr2d[0].length; j++) {
                arr2d[i][j] = new Data(index);
                index++;
            }
        }

        System.out.println("Data array :");
        for (int i = 0; i < arr2d.length; i++) {
            for (int j = 0; j < arr2d[0].length; j++) {
                System.out.print(arr2d[i][j].getData()+" ");
            }
            System.out.println();
        }

        System.out.println("ClockedWiseTraverse version :");
        ClockWiseTrevarse trv = new ClockWiseTrevarse(arr2d);

        ConcreteDataAggregate traversedMatrix = trv.res;

        DataIterator dataIterator = traversedMatrix.getIterator();
        while(dataIterator.isDone()){
            System.out.print(dataIterator.currentItem().getData()+" ");
            dataIterator.next();
        }
    }
}

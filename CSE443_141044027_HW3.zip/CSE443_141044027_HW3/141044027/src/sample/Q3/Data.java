package sample.Q3;

/**
 * Data sınıfı . Integer veri tutmak için
 */
public class Data {
    /**
     * Data field
     */
    private int data;

    /**
     * Constructor
     */
    public Data(){
        this.data=0;
    }

    /**
     * Constructor
     * @param data
     */
    public Data(int data){
        this.data=data;
    }

    /**
     * getter
     * @return intdata
     */
    public int getData() {
        return data;
    }

    /**
     * Setter
     * @param data
     */
    public void setData(int data) {
        this.data = data;
    }


}

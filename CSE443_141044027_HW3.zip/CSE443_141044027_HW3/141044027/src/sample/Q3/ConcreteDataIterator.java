package sample.Q3;

import java.util.NoSuchElementException;

/**
 * DataIterator interfaceinden implement edilen ConcreteDataIterator sınıfı .
 */
public class ConcreteDataIterator implements DataIterator {
    /**
     * Data field . İterate edicek olan sınıfın bilgileri için
     */
    private ConcreteDataAggregate concreteDataAggregate;
    /**
     * index
     */
    private int index=0;

    /**
     * Constructor
     * @param concreteDataAggregate
     */
    public ConcreteDataIterator(ConcreteDataAggregate concreteDataAggregate){
        this.concreteDataAggregate=concreteDataAggregate;
    }

    /**
     * Overrrided next() method
     * @return Data
     * @throws NoSuchElementException
     */
    @Override
    public Data next() throws NoSuchElementException{
        if(hasNext())
            return concreteDataAggregate.getItem(index++);
        else
            throw new NoSuchElementException();
        /*
        index++;
        if(isDone()) return concreteDataAggregate.getItem(this.index);
        else
            return null;
    */}

    /**
     * Override hasNext() method
     * @return boolean
     */
    @Override
    public boolean hasNext(){
        return index < concreteDataAggregate.countData();
    }

    /**
     * Overrided isDOne() method
     * @return boolean
     */
    @Override
    public boolean isDone() {
        return index < concreteDataAggregate.countData();
    }

    /**
     * Overrided currentItem() method
     * @return Data
     */
    @Override
    public Data currentItem() {
        return this.concreteDataAggregate.getItem(this.index);
    }

    /**
     * Getter for size
     * @return int
     */
    public int getSize(){
        return this.concreteDataAggregate.countData();
    }

    /**
     * İçerideki sınıfta parametre ile belirtilen indexteki Data verisini çeker .
     * @param index
     * @return Data
     */
    public Data getElementAt(int index){
        return concreteDataAggregate.getItem(index);
    }
}

package sample.Q1;

/**
 * ModernPayment adaptörüdür . İçerisinde ModernPayment
 * interfaci tutarak özelliklerini TurboPayment yapısına aktarmıştır .
 */
public class ModernPayAdapter implements TurboPayment {
    /**
     * Data field
     */
    ModernPayment modernPayment;

    /**
     * Constructor
     * @param modernPayment
     */
    public ModernPayAdapter(ModernPayment modernPayment){
        this.modernPayment=modernPayment;
    }

    /**
     * Override edilmiş payInTurbo sınıfıdır . içerisinde datafieldde tutulan modernPayment yapısının pay metodunu
     * çağırır ve return eder .
     * @param turboCardNo
     * @param turboAmount
     * @param destinationTurboOfCourse
     * @param installmentsButInTurbo
     * @return int
        */
    @Override
    public int payInTurbo(String turboCardNo, float turboAmount, String destinationTurboOfCourse, String installmentsButInTurbo) {
        return modernPayment.pay(turboCardNo,turboAmount,destinationTurboOfCourse,installmentsButInTurbo);
    }
}

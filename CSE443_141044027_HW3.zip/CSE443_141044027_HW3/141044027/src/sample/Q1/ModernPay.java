package sample.Q1;

/**
 * Leaf yapısı için ModernPay
 */
public class ModernPay implements ModernPayment {

    /**
     * Ekrana bilgileri basar ve return değeri ödeme miktarıdır .
     * @param cardNo
     * @param amount
     * @param destination
     * @param installments
     * @return int
     */
    @Override
    public int pay(String cardNo, float amount, String destination, String installments) {
        System.out.println("ModernPayment ==> "+"CardNo: "+cardNo+" Amount:"+amount+" Destination:"+destination
                +" installments:"+installments);
        return (int)amount;
    }
}

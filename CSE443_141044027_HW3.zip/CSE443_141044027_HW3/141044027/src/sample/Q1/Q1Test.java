package sample.Q1;

/**
 * Q4Test Sınıfı
 */
public class Q1Test {
    public static void main(String args[]){
        ModernPay modernPay = new ModernPay();
        TurboPayment adapter = new ModernPayAdapter(modernPay);

        System.out.println("ModernPayment :");
        modernPay.pay("12345",50,"creditcart1","2");

        System.out.println();

        System.out.println("TurboPayment with ModernPaymentAdapter :");
        testTurboPayment(adapter,"12345",50,"creditcart1",
                "2");
    }

    /**
     * Q4Test Method . ModernPayment interfaceinin özelliğini turbapayment e ekler .
     * @param turboPayment
     * @param turboCardNo
     * @param turboAmount
     * @param destinationTurboOfCourse
     * @param installmentsButInTurbo
     */
    public static void testTurboPayment(TurboPayment turboPayment,String turboCardNo,float turboAmount,
                                 String destinationTurboOfCourse, String installmentsButInTurbo){

        turboPayment.payInTurbo(turboCardNo,turboAmount,destinationTurboOfCourse,installmentsButInTurbo);
    }
}

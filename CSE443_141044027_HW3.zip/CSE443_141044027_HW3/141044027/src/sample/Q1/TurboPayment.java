package sample.Q1;

/**
 * TurboPayment interface
 */
public interface TurboPayment {
    /**
     * İmplement edildiğinde bilgileri ekrana basar ve return değeri ödeme miktarıdır .
     * @param turboCardNo
     * @param turboAmount
     * @param destinationTurboOfCourse
     * @param installmentsButInTurbo
     * @return int
     */
    int payInTurbo(String turboCardNo, float turboAmount,
                   String destinationTurboOfCourse, String installmentsButInTurbo);
}

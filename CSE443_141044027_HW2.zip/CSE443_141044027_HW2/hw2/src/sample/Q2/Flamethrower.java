package sample.Q2;

/**
 * Flamethrower sınıf . Abstract weaponDecoder sınıfını extend edr .
 */
public class Flamethrower extends WeaponDecoder {
    /**
     * Constructor
     * @param component
     */
    public Flamethrower (Component component){
        super(component);
        this.weaponName="Flamethrower";
        this.weaponCost=50;
        this.weaponWeight=2;
    }

    /**
     * Default constructor
     */
    public Flamethrower(){
        this.weaponName="Flamethrower";
        this.weaponCost=50;
        this.weaponWeight=2;
    }

    /**
     * Overrided wear method
     * @return Strin
     */
    @Override
    public String wear() {
        return (this.weaponName+" weared");
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.weaponCost+this.component.totalcost();
    }

    /**
     * Overrided totalweight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.weaponWeight + this.component.totalweight();
    }

    /**
     * fire method
     */
    public void fire(){
        System.out.println(this.weaponName+" fired.");
    }
}

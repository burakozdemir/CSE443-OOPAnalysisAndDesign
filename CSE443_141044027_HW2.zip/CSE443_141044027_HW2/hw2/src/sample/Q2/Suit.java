package sample.Q2;

/**
 * Zırhlar için ortak abstract sınıf .
 */
public abstract class Suit implements Component {
    double suitCost=0;
    double suitWeight=0;
    /**
     * İsim için ortak field.
     */
    String name;

    /**
     * Totalcost
     * @return double
     */
    @Override
    public double totalcost() {
        return 0;
    }

    /**
     * Totalcost
     * @return double
     */
    @Override
    public double totalweight() {
        return 0;
    }
}

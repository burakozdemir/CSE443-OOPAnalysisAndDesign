package sample.Q2;

/**
 * Laser sınıfı . Abstract WeaponDecoder sınıfını extend eder .
 */
public class Laser extends WeaponDecoder{
    /**
     * Constructor
     * @param component
     */
    public Laser (Component component){
        super(component);
        this.weaponName="Laser";
        this.weaponCost=200;
        this.weaponWeight=5.5;
    }

    /**
     * Overrided wear method
     * @return String
     */
    @Override
    public String wear() {
        return (this.weaponName+" weared");
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.weaponCost+component.totalcost();
    }

    /**
     * Overrided totalweight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.weaponWeight+component.totalweight();
    }

    /**
     * fire method
     */
    public void fire(){
        System.out.println(this.weaponName+" fired.");
    }
}

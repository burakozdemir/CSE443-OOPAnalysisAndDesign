package sample.Q2;

/**
 * Silahlar için ortak abstract sınıf .
 */
public abstract class WeaponDecoder implements Component {
    public double weaponCost=0;
    public double weaponWeight=0;
    /**
     * Silah için içerde tutulan componentin ortak field alanı .
     */
    Component component;
    /**
     * Silahların ismi için ortak isim alanı
     */
    String weaponName;

    /**
     * Constructor
     * @param component
     */
    public WeaponDecoder(Component component){
        this.component=component;
    }

    /**
     * Default constructor
     */
    public WeaponDecoder(){
        this.weaponCost=0;
        this.weaponWeight=0;
    }

    /**
     * Giyme metodu
     * @return String
     */
    @Override
    public String wear(){
        return ("Weapon weared");
    }

    /**
     * totalcost
     * @return double
     */
    @Override
    public double totalcost() {
        return this.weaponCost;
    }

    /**
     * totalweapon
     * @return double
     */
    @Override
    public double totalweight() {
        return this.weaponWeight;
    }
}

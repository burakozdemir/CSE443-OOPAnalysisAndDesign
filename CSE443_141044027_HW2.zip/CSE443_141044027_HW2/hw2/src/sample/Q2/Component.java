package sample.Q2;

/**
 * Tüm içeriklerin ortak interface'i
 */
public interface Component {
    /**
     * Giyme metodu
     * @return String
     */
    String wear();

    /**
     * Totalcost
     * @return double
     */
    double totalcost();

    /**
     * TotalWeight
     * @return double
     */
    double totalweight();
}

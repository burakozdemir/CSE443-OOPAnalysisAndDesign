package sample.Q2;

/**
 * RocketLauncher sınıfı .Abstract weaponDecoder sınıfını extend eder .
 */
public class RocketLauncher extends WeaponDecoder {
    /**
     * Constructor
     * @param component
     */
    public RocketLauncher (Component component){
        super(component);
        this.weaponName="RocketLauncher";
        this.weaponCost=150;
        this.weaponWeight=7.5;
    }

    /**
     * Default constrctor
     */
    public RocketLauncher(){
        this.weaponName="RocketLauncher";
        this.weaponCost=150;
        this.weaponWeight=7.5;
    }

    /**
     * Overrided wear method
     * @return string
     */
    @Override
    public String wear() {
        return (this.weaponName+" weared");
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.weaponCost+component.totalcost();
    }

    /**
     * Overrided totalweight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.weaponWeight+component.totalweight();
    }

    /**
     * fire method
     */
    public void fire(){
        System.out.println(this.weaponName+" fired.");
    }
}

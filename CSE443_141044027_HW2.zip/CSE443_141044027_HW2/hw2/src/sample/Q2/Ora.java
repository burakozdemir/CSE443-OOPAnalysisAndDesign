package sample.Q2;

/**
 * Ora sınıfı . Abstract Suit sınıfını extends eder .
 */
public class Ora extends Suit{
    /**
     * constructor
     */
    public Ora(){
        this.name="Ora";
        this.suitCost=1500;
        this.suitWeight=30;
    }

    /**
     * Overrided wear method
     * @return string
     */
    @Override
    public String wear() {
        return  ("Weared "+name);
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.suitCost ;
    }

    /**
     * Overrided totalweight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.suitWeight ;
    }
}

package sample.Q2;

import java.util.Vector;

/**
 * Test sınıfı
 */
public class Soldier {
    Vector<Component> equip = new Vector<>();
    double totalEquipped;

    public Soldier(){ }

    /**
     * Static main
     * @param args
     */
    public static void main(String[] args){
        Soldier soldier = new Soldier();

        WeaponDecoder w = null ;
        Suit suit = null;

        
        Dec dec = new Dec();
        Flamethrower flamethrower = new Flamethrower(dec);flamethrower.wear();soldier.equip.add(flamethrower);
        AutoRifle autoRifle = new AutoRifle(flamethrower);autoRifle.wear();soldier.equip.add(autoRifle);
        AutoRifle autoRifle1 = new AutoRifle(autoRifle);autoRifle1.wear();soldier.equip.add(autoRifle1);
        RocketLauncher rocketLauncher = new RocketLauncher(autoRifle1);rocketLauncher.wear();soldier.equip.add(rocketLauncher);
        soldier.totalEquipped=rocketLauncher.totalcost();


        System.out.println("Total Cost Soldier1 :"+rocketLauncher.totalcost());

    }
}

package sample.Q2;

/**
 * Tor sınıfı . Abstract suit sınıfını extend eder .
 */
public class Tor extends Suit {
    /**
     * Constructor
     */
    public Tor(){
        this.name="Tor";
        this.suitCost=5000;
        this.suitWeight=50;
    }

    /**
     * Overrided wear method
     * @return string
     */
    @Override
    public String wear() {
        return ("Weared "+name);
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.suitCost ;
    }

    /**
     * Overrided totalweigh method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.suitWeight ;
    }
}

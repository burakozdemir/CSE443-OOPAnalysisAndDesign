package sample.Q2;

/**
 * AutoRifle sınıf . WeaponDecoder abstract sınıfını extend eder .
 */
public class AutoRifle extends WeaponDecoder {
    /**
     * Constructor
     * @param component
     */
    public AutoRifle (Component component){
        super(component);
        this.weaponName="AutoRifle";
        this.weaponCost=30;
        this.weaponWeight=1.5;
    }

    /**
     * Overrided wear method
     * @return String
     */
    @Override
    public String wear() {
        return (this.weaponName+" weared");
    }

    /**
     * Overrided totalCost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.weaponCost+component.totalcost();
    }

    /**
     * Overrided totalWeight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.weaponWeight+component.totalweight();
    }

    /**
     * Fire method
     */
    public void fire(){
        System.out.println(this.weaponName+" fired.");
    }
}

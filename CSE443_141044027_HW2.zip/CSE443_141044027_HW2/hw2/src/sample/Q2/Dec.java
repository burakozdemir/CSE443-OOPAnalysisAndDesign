package sample.Q2;

/**
 * Dec sınıfı . Suit abstract sınıfını extend eder .
 */
public class Dec extends Suit {
    /**
     * Constructor
     */
    public Dec(){
        this.name="Dec";
        this.suitCost=500;
        this.suitWeight=25;
    }

    /**
     * Overrided wear method
     * @return String
     */
    @Override
    public String wear() {
        return ("Weared "+name);
    }

    /**
     * Overrided totalcost method
     * @return double
     */
    @Override
    public double totalcost() {
        return this.suitCost;
    }

    /**
     * Overrided totalWeight method
     * @return double
     */
    @Override
    public double totalweight() {
        return this.suitWeight;
    }
}

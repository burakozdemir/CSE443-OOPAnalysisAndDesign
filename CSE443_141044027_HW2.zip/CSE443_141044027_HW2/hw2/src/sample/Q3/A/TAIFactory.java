package sample.Q3.A;

/**
 * TAIFactory sınıfı .
 */
public class TAIFactory {
    /**
     * istenilen tipte uçak üretir .
     * @param type
     * @return TAIPlane
     */
    public TAIPlane createPlane(String type){
        switch (type){
            case "TPX_100" : return new TPX_100();
            case "TPX_200" : return new TPX_200();
            case "TPX_300" : return new TPX_300();
            default: return null;
        }
    }
}

package sample.Q3.A;

/**
 * Uçaklar için interface
 */
public interface Plane {
    /**
     * iskelet
     */
    void constructSkeleton();

    /**
     * Motor
     */
    void  placeEngines();

    /**
     * Koltuklar
     */
    void placeSeats();
}

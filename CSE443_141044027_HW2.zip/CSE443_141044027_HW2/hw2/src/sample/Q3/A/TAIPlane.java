package sample.Q3.A;

/**
 * Abstract TAIPlane sınıfı . Plane interface ini implements eder .
 */
public abstract class TAIPlane implements Plane{
    String type;
    String purpose;
    String skeleton;
    String engine;
    String seat;
}

package sample.Q3.A;

/**
 * Client sınıfı. içerde factory sınıfını tutar
 * ve methodu ile istediği sınıfı oluşturur .
 */
public class TAI {
    TAIFactory factory;

    /**
     * Constructor
     * @param fact
     */
    public TAI(TAIFactory fact){
        this.factory=fact;
    }

    /**
     * Plane sınıfnı oluşturuyor .
     * @param type
     * @return TAIPLane
     */
    public TAIPlane orderPlane(String type){
        TAIPlane plane;
        plane=factory.createPlane(type);
        plane.constructSkeleton();
        plane.placeEngines();
        plane.placeSeats();
        return plane;
    }

    /**
     * Static main
     * @param args
     */
    public static void main(String [] args){
        TAIFactory factory = new TAIFactory();

        TAI tai = new TAI(factory);

        TAIPlane plane = tai.orderPlane("TPX_100");
    }
}

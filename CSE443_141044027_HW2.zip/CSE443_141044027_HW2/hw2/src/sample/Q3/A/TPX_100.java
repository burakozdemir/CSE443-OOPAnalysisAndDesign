package sample.Q3.A;

/**
 * TPX_100 sınıfı . Abstract TAIPlane sınıfını extend eder .
 */
public class TPX_100 extends TAIPlane {
    public StringBuilder result = new StringBuilder();

    /**
     * Constructor
     */
    public TPX_100(){
        this.type="TPX_100";
        this.purpose="Domestic flights";
        this.skeleton="Aluminum";
        this.engine="Single";
        this.seat="50";
    }

    /**
     * Overrided iskelet method
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
        result.append(this.type + " plane skeleton : "+this.skeleton+" constructed.\n");
    }

    /**
     * Overrided engine method
     */
    @Override
    public void placeEngines() {
        System.out.println(this.type + " plane engine : "+this.engine+" placed.");
        result.append(this.type + " plane engine : "+this.engine+" placed.\n");
    }

    /**
     * Overrided koltuk method
     */
    @Override
    public void placeSeats() {
        System.out.println(this.type + " plane seat : "+this.seat+" placed.");
        result.append(this.type + " plane seat : "+this.seat+" placed.");
    }
}

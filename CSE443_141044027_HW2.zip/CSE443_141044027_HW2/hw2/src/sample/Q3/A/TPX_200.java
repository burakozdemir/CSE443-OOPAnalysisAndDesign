package sample.Q3.A;

/**
 * TPX_200 sınıfı . Abstract TAIPlane sınıfını extend eder .
 */
public class TPX_200 extends TAIPlane {
    public StringBuilder result = new StringBuilder();

    /**
     * Constrctor
     */
    public TPX_200(){
        this.type="TPX_200";
        this.purpose="Domestic and short international flights";
        this.skeleton="Nickel";
        this.engine="Twin";
        this.seat="100";
    }

    /**
     * Overrided iskelet method
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
        result.append(this.type + " plane skeleton : "+this.skeleton+" constructed.\n");
    }

    /**
     * Overrided motor method
     */
    @Override
    public void placeEngines() {
        System.out.println(this.type + " plane engine : "+this.engine+" placed.");
        result.append(this.type + " plane engine : "+this.engine+" placed.\n");
    }

    /**
     * Overrided koltuk method
     */
    @Override
    public void placeSeats() {
        System.out.println(this.type + " plane seat : "+this.seat+" placed.");
        result.append(this.type + " plane seat : "+this.seat+" placed.");
    }
}

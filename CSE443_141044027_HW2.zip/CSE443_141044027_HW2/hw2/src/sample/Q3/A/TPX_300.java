package sample.Q3.A;

/**
 * TPX_300 sınıfı. Abstract TAIPlane sınıfnı extend eder .
 */
public class TPX_300 extends TAIPlane{
    public StringBuilder result = new StringBuilder();

    /**
     * Constructor
     */
    public TPX_300(){
        this.type="TPX_300";
        this.purpose="Transatlantic flights";
        this.skeleton="Titanium";
        this.engine="Quadro";
        this.seat="250";
    }

    /**
     * Overrided iskelet method
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
        result.append(this.type + " plane skeleton : "+this.skeleton+" constructed.\n");
    }

    /**
     * Overrided motor method
     */
    @Override
    public void placeEngines() {
        System.out.println(this.type + " plane engine : "+this.engine+" placed.");
        result.append(this.type + " plane engine : "+this.engine+" placed.\n");
    }

    /**
     * Overrided koltuk method
     */
    @Override
    public void placeSeats() {

        System.out.println(this.type + " plane seat : "+this.seat+" placed.");
        result.append(this.type + " plane seat : "+this.seat+" placed.");
    }
}

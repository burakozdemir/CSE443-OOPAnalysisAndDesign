package sample.Q3.B;

/**
 *  OtherEngine sınıfı . Abstract Engine sınıfını extend eder .
 */
public class OtherEngine extends Engine {
    /**
     * constructor
     * @param model
     */
    public OtherEngine(String model) {
        super(model);
    }
}

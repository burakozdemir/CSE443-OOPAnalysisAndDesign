package sample.Q3.B;

/**
 * Diğer factory sınıfları için abstarct yapı
 */
public abstract class TAIFactory {
    String factoryName;

    /**
     * Constructor
     * @return TAIPlane
     */
    public abstract TAIPlane createPlane();
}

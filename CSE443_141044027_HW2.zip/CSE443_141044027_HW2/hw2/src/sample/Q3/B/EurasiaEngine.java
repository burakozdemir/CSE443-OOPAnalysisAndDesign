package sample.Q3.B;

/**
 *  EurasiaEngine sınıfı . Abstract Engine sınıfını extend eder .
 */
public class EurasiaEngine extends Engine {
    /**
     * Constructor
     * @param model
     */
    public EurasiaEngine(String model) {
        super(model);
    }
}

package sample.Q3.B;

/**
 * Abstract TAIPlane sınıfı . Plane interface ini implement eder
 */
public abstract class TAIPlane implements Plane{
    /**
     * Uçak tipi
     */
    String type;
    /**
     * Uçak amacı
     */
    String purpose;
    /**
     * İskelet hammaddesi
     */
    String skeleton;
    /**
     * Motor hammaddesi
     */
    String engine;
    /**
     * Koltuk sayısı
     */
    String seat;
    /**
     * Motor tip
     */
    Engine engineType;
    /**
     * Koltuk tip
     */
    Seat seatType;


}

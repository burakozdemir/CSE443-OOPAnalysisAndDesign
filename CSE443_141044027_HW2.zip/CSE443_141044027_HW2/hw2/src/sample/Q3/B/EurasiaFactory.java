package sample.Q3.B;

/**
 *  EurasiaFactory sınıfı . Abstract TAIFactory sınıfını extend eder .
 */
public class EurasiaFactory extends TAIFactory {
    /**
     * constructor
     */
    public EurasiaFactory(){
        this.factoryName="Eurasia";
    }

    /**
     * Overrided createPlane
     * @return TAIPlane
     */
    @Override
    public TAIPlane createPlane() {
        return new TPX_200();
    }
}

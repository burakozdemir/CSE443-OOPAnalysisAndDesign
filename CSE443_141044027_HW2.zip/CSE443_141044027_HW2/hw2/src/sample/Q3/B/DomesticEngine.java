package sample.Q3.B;

/**
 * DomesticEngine sınıfı . Abstract Engine sınıfını extend eder .
 */
public class DomesticEngine extends Engine {
    /**
     * Constructor
     * @param model
     */
    public DomesticEngine(String model) {
        super(model);
    }
}

package sample.Q3.B;

/**
 *  EurasiaSeat sınıfı . Abstract Seat sınıfını extend eder .
 */
public class EurasiaSeat extends Seat {
    /**
     * Constructor
     * @param model
     */
    public EurasiaSeat(String model) {
        super(model);
    }
}

package sample.Q3.B;

/**
 * OtherFactory sınıfı . Abstract TAIFactory sınıfını extend eder .
 */
public class OtherFactory extends TAIFactory {
    /**
     * Constructor
     */
    public OtherFactory(){
        this.factoryName="Other";
    }

    /**
     * Overrided createPlane
     * @return TAIPlane
     */
    @Override
    public TAIPlane createPlane() {
        return new TPX_300();
    }
}

package sample.Q3.B;

/**
 * TPX_200 sınıfı . TAIPlane sınıfını extend eder .
 */
public class TPX_200 extends TAIPlane {
    public String result;

    /**
     * Constructor
     */
    public TPX_200(){
        this.type="TPX_200";
        this.purpose="Domestic and short international flights";
        this.skeleton="Nickel";
        this.engine="Twin";
        this.seat="100";
        this.engineType= new EurasiaEngine("Turbofan");
        this.seatType = new EurasiaSeat("Linen");
    }

    /**
     * Overrided toString()
     * @return String
     */
    @Override
    public String toString(){
        StringBuilder res = new StringBuilder();
        res.append(this.type + " plane skeleton : "+this.skeleton+" constructed.\n");
        res.append(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed.\n");
        res.append(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.\n");
        result=res.toString();
        return res.toString();
    }

    /**
     * Overrided iskelet metod
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
    }

    /**
     * Overrided motor metod
     */
    @Override
    public void placeEngines() {
        System.out.println(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed.");
    }

    /**
     * Overrided koltuk metod
     */
    @Override
    public void placeSeats() {
        System.out.println(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.");
    }
}

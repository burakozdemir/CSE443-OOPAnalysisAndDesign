package sample.Q3.B;

/**
 * TPX_300 sınıfı . TAIPlane sınıfını extend eder .
 */
public class TPX_300 extends TAIPlane{
    public String result;
    /**
     * Constructor
     */
    public TPX_300(){
        this.type="TPX_300";
        this.purpose="Transatlantic flights";
        this.skeleton="Titanium";
        this.engine="Quadro";
        this.seat="250";
        this.engineType= new OtherEngine("Geared_turbofan");
        this.seatType = new OtherSeat("Leather");
    }

    /**
     * Overrided toString()
     * @return String
     */
    @Override
    public String toString(){
        StringBuilder res = new StringBuilder();
        res.append(this.type + " plane skeleton : "+this.skeleton+" constructed.\n");
        res.append(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed.\n");
        res.append(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.\n");
        result=res.toString();
        return res.toString();
    }

    /**
     * Overrided iskelet metod
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
    }

    /**
     * Overrided motor metod
     */
    @Override
    public void placeEngines() {

        System.out.println(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed.");
    }

    /**
     * Overrided koltuk metod
     */
    @Override
    public void placeSeats() {

        System.out.println(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.");
    }
}

package sample.Q3.B;

/**
 * TPX_100 sınıfı . TAIPlane sınıfını extend eder .
 */
public class TPX_100 extends TAIPlane {
    public String result;

    /**
     * Constructor
     */
    public TPX_100(){
        this.type="TPX_100";
        this.purpose="Domestic flights";
        this.skeleton="Aluminum";
        this.engine="Single";
        this.seat="50";
        this.engineType= new DomesticEngine("Turbojet");
        this.seatType = new DomesticSeat("Velvet");
    }

    /**
     * Overrided toString()
     * @return String
     */
    @Override
    public String toString(){
        StringBuilder res = new StringBuilder();
        res.append(this.type + " plane skeleton : "+this.skeleton+" constructed. \n");
        res.append(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed. \n");
        res.append(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.\n");
        result=res.toString();
        return res.toString();
    }

    /**
     * Overrided iskelet metod
     */
    @Override
    public void constructSkeleton() {
        System.out.println(this.type + " plane skeleton : "+this.skeleton+" constructed.");
    }

    /**
     * Overrided motor metod
     */
    @Override
    public void placeEngines() {
        System.out.println(this.type + " plane engine : "+this.engine+" engineType : "+this.engineType.model+" placed.");
    }

    /**
     * Overrided koltuk metod
     */
    @Override
    public void placeSeats() {
        System.out.println(this.type + " plane seat : "+this.seat+" seatType: "+this.seatType.model+" placed.");
    }
}

package sample.Q3.B;

/**
 * DomesticFactory sınıfı . Abstract TAIFactory sınıfını extend eder .
 */
public class DomesticFactory extends TAIFactory {
    public DomesticFactory(){
        this.factoryName="Domestic";
    }

    /**
     * Overrided createPlane sınıfı .
     * @return TAIPlane
     */
    @Override
    public TAIPlane createPlane() {
        return new TPX_100();
    }
}

package sample.Q3.B;

/**
 *  OtherSeat sınıfı . Abstract Seat sınıfını extend eder .
 */
public class OtherSeat extends Seat {
    /**
     * Constructor
     * @param model
     */
    public OtherSeat(String model) {
        super(model);
    }
}

package sample.Q3.B;

/**
 * DomesticSeat sınıfı . Abstract Seat sınıfını extend eder .
 */
public class DomesticSeat extends Seat {
    /**
     * constructor
     * @param model
     */
    public DomesticSeat(String model) {
        super(model);
    }
}

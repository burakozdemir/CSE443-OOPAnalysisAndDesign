package sample.Q3.B;

/**
 * Test Client sınıfı .
 */
public class TAICompany {
    /**
     * Factory sınıfı için field.
     */
    TAIFactory factory;

    /**
     * Constructor
     * @param fact
     */
    public TAICompany(TAIFactory fact){
        switch (fact.factoryName){
            case "Domestic":this.factory= new DomesticFactory();break;
            case "Eurasia":this.factory= new EurasiaFactory();break;
            case "Other":this.factory= new OtherFactory();break;
            default:
                System.out.println("No factory !");break;
        }
    }

    /**
     * Uçağı hazır hale getirir .
     * @return TAIPlane
     */
    public TAIPlane orderPlane(){
        TAIPlane plane;
        plane=factory.createPlane();
        plane.constructSkeleton();
        plane.placeEngines();
        plane.placeSeats();
        return plane;
    }

    /**
     * Static main
     * @param args
     */
    public static void main(String [] args){
        TAIFactory factory = new DomesticFactory();
        TAICompany tai = new TAICompany(factory);
        TAIPlane plane = tai.orderPlane();

        System.out.println("-------------------");

        TAIFactory factory2 = new EurasiaFactory();
        tai = new TAICompany(factory2);
        plane = tai.orderPlane();

        System.out.println("-----------------");

        TAIFactory factory3 = new OtherFactory();
        tai = new TAICompany(factory3);
        plane = tai.orderPlane();

    }
}

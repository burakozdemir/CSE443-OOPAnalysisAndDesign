package sample.Q3.B;

/**
 * Abstract Engine sınıfı
 */
public abstract class Engine {
    String model;

    /**
     * Constructor
     * @param model
     */
    public Engine(String model){this.model=model;}
}

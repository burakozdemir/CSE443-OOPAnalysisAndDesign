package sample.Q3.B;

/**
 * Abstract Seat sınıfı
 */
public abstract class Seat {
    String model;

    /**
     * Constructor
     * @param model
     */
    public Seat(String model){this.model=model;}
}

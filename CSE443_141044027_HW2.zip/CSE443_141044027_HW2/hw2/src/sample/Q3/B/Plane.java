package sample.Q3.B;

/**
 * Uçaklar için interface sınıfı
 */
public interface Plane {
    void constructSkeleton();
    void  placeEngines();
    void placeSeats();
}

package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sample.Q2.*;
import sample.Q3.A.TAI;
import sample.Q3.A.TAIFactory;
import sample.Q3.A.TAIPlane;
import sample.Q3.B.*;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * GUI Controller
 */
public class Controller implements Initializable {

    @FXML
    ComboBox<String> combobox;

    @FXML
    TextField flamethrower;

    @FXML
    TextField autorifle;

    @FXML
    TextField rocketlauncher;

    @FXML
    TextField laser;

    @FXML
    TextArea out;

    @FXML
    TextArea outlog;
    ///////////////////

    @FXML
    ComboBox<String> patternType;

    @FXML
    ComboBox<String> planeType;

    @FXML
    TextArea output;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> list = FXCollections.observableArrayList();
        list.addAll("dec","ora","tor");
        combobox.setItems(list);

        ObservableList<String> list2 = FXCollections.observableArrayList();
        list2.addAll("Factory","Abstract_Factory");
        patternType.setItems(list2);

        ObservableList<String> list3 = FXCollections.observableArrayList();
        list3.addAll("TPX_100","TPX_200","TPX_300");
        planeType.setItems(list3);

    }

    @FXML
    void hesapla(ActionEvent e) {
        out.clear();
        outlog.clear();

        StringBuilder res = new StringBuilder();
        StringBuilder res2 = new StringBuilder();

        Suit soldier = null;
        WeaponDecoder weapon = null;

        if(combobox.getValue() == "dec"){
            soldier = new Dec();
        }else if(combobox.getValue() == "ora"){
            soldier = new Ora();
        }else if(combobox.getValue() == "tor"){
            soldier = new Tor();
        }
        res.append(soldier.wear() + "\n");

        weapon = clear(weapon,soldier);


        for (int i = 0; i <Integer.parseInt(flamethrower.getText()) ; i++) {
            weapon = new Flamethrower(weapon);
            res.append(weapon.wear()  + "\n");
        }

        for (int i = 0; i <Integer.parseInt(autorifle.getText()) ; i++) {
            weapon = new AutoRifle(weapon);
            res.append(weapon.wear()  + "\n");
        }

        for (int i = 0; i <Integer.parseInt(rocketlauncher.getText()) ; i++) {
            weapon = new RocketLauncher(weapon);
            res.append(weapon.wear()  + "\n");
        }

        for (int i = 0; i <Integer.parseInt(laser.getText()) ; i++) {
            weapon = new Laser(weapon);
            res.append(weapon.wear()  + "\n");
        }

        outlog.setText(res.toString());

        res2.append("TotalCost : " +Double.toString(weapon.totalcost()) + "\n");
        res2.append("TotalWeight : " +Double.toString(weapon.totalweight()) + "\n");

        out.setText(res2.toString());

    }
    @FXML
    void hesapla2(ActionEvent e) {
        output.clear();

        TAIFactory factoryT = new TAIFactory();
        TAI taiT = new TAI(factoryT);
        sample.Q3.A.TPX_100 planeT1 = null ;
        sample.Q3.A.TPX_200 planeT2 = null ;
        sample.Q3.A.TPX_300 planeT3 = null ;
        if(patternType.getValue()=="Factory"){

            if(planeType.getValue()=="TPX_100"){
                    planeT1 = (sample.Q3.A.TPX_100)taiT.orderPlane("TPX_100");
                    output.setText(planeT1.result.toString());
            }else if(planeType.getValue()=="TPX_200"){
                    planeT2 = (sample.Q3.A.TPX_200)taiT.orderPlane("TPX_200");
                    output.setText(planeT2.result.toString());
            }else if(planeType.getValue()=="TPX_300"){
                    planeT3 = (sample.Q3.A.TPX_300)taiT.orderPlane("TPX_300");
                    output.setText(planeT3.result.toString());
            }

        }
        else if(patternType.getValue()=="Abstract_Factory"){
            sample.Q3.B.TPX_100 plane ;
            sample.Q3.B.TPX_200 plane2 ;
            sample.Q3.B.TPX_300 plane3;
            if(planeType.getValue()=="TPX_100"){
                sample.Q3.B.TAIFactory factory = new DomesticFactory();
                TAICompany tai = new TAICompany(factory);
                plane = (sample.Q3.B.TPX_100)tai.orderPlane();
                plane.toString();
                output.setText(plane.result);

            }else if(planeType.getValue()=="TPX_200"){
                sample.Q3.B.TAIFactory factory = new EurasiaFactory();
                TAICompany tai = new TAICompany(factory);
                plane2 = (sample.Q3.B.TPX_200)tai.orderPlane();
                plane2.toString();
                output.setText(plane2.result);

            }else if(planeType.getValue()=="TPX_300"){
                sample.Q3.B.TAIFactory factory = new OtherFactory();
                TAICompany tai = new TAICompany(factory);
                plane3 = (sample.Q3.B.TPX_300) tai.orderPlane();
                plane3.toString();
                output.setText(plane3.result);
            }
        }

    }
    private WeaponDecoder clear(WeaponDecoder weapon,Suit soldier){
        weapon = new Flamethrower(soldier);
        weapon.weaponCost -= 50;
        weapon.weaponWeight -= 2;
        return weapon;
    }

}
